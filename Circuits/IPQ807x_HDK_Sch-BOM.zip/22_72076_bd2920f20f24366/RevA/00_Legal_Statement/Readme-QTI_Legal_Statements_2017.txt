Confidential and Proprietary � Qualcomm Technologies, Inc.

� 2017 Qualcomm Technologies, Inc. All rights reserved.

NO PUBLIC DISCLOSURE PERMITTED: Please report postings of this document on public servers or websites to: DocCtrlAgent@qualcomm.com. 

Restricted Distribution:  Not to be distributed to anyone who is not an employee of either Qualcomm Technologies, Inc. or its affiliated companies without the express approval of Qualcomm Configuration Management.

Not to be used, copied, reproduced, or modified in whole or in part, nor its contents revealed in any manner to others without the express written permission of Qualcomm Technologies, Inc. 

Qualcomm is a trademark of Qualcomm Incorporated, registered in the United States and other countries. Other product and brand names may be trademarks or registered trademarks of their respective owners. 

This technical data may be subject to U.S. and international export, re-export, or transfer (�export�) laws. Diversion contrary to U.S. and international law is strictly prohibited.


Qualcomm Technologies, Inc.
5775 Morehouse Drive
San Diego, CA 92121
U.S.A

















